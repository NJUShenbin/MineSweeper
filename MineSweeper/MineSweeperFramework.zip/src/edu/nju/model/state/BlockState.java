package edu.nju.model.state;

/**
 * 逻辑运行中的状态
 * @author Wangy
 *
 */
public enum BlockState {
	UNCLICK,CLICK,FLAG
	
}
