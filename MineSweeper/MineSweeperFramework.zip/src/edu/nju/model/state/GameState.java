package edu.nju.model.state;

/**
 * 游戏状态，包括运行中，结束，暂停
 * @author Wangy
 *
 */
public enum GameState {
	RUN,OVER,PAUSE
}
