package edu.nju.network;

public class Configure {
	public static String SERVER_ADDRESS = "127.0.0.1";
	public final static int PORT = 7048;
	
	public final static String MSG_TYPE = "TYPE";
	public final static String MSG_DATA = "DATA";
	
}
