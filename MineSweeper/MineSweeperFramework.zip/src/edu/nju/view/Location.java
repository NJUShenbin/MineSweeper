/*
 * Created on Dec 21, 2014
 *
 * TODO to mark the coordinate of button
 */
package edu.nju.view;

public class Location {
	final public int x;

	final public int y;

	public Location(int x, int y) {
		this.x = x;
		this.y = y;
	}
}