package edu.nju.controller.msgqueue.operation;

public abstract class MineOperation {
	public abstract void execute();
}
