package edu.nju.controller.service;

public interface HostControllerService {
	/**
	 * 作为主机建立网络连接
	 * @return
	 */
	public boolean serviceetupHost();
}
